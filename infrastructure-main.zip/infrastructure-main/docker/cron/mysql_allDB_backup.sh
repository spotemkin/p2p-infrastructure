#!/bin/bash

MYSQL_USER="root"
MYSQL_PASSWORD="${MYSQL_ROOT_PASSWORD}"
DATABASE_NAME="--all-databases"
MYSQL_HOST="mysqlserver" # Используем алиас для обращения к серверу MySQL
BACKUP_PATH="/dumps"

mysqldump -h $MYSQL_HOST -u$MYSQL_USER -p$MYSQL_PASSWORD $DATABASE_NAME > $BACKUP_PATH/backup_$(date +%F).sql
